package me.davidthestarman.elytraDogfights.inventory;

import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;

public class RedTeamInventory {
    ItemStack sword = new ItemStack(Material.STONE_SWORD, 1);
    ItemMeta swordMeta = sword.getItemMeta();

    ItemStack bow = new ItemStack(Material.BOW, 1);
    ItemMeta bowMeta = bow.getItemMeta();

    ItemStack arrow = new ItemStack(Material.ARROW, 1);

    ItemStack rocket = new ItemStack(Material.FIREWORK_ROCKET, 64);
    FireworkMeta rocketMeta = (FireworkMeta) rocket.getItemMeta();

    ItemStack elytra = new ItemStack(Material.ELYTRA, 1);
    ItemMeta elytraMeta = elytra.getItemMeta();

    ItemStack helmet = new ItemStack(Material.LEATHER_HELMET, 1);
    LeatherArmorMeta helmetMeta = (LeatherArmorMeta) helmet.getItemMeta();

    ItemStack boots = new ItemStack(Material.LEATHER_BOOTS, 1);
    LeatherArmorMeta bootsMeta = (LeatherArmorMeta) boots.getItemMeta();

    public void redInventory(Player player) {
        // sets sword metadata
        swordMeta.setDisplayName(ChatColor.AQUA + "Whacker");
        swordMeta.addEnchant(Enchantment.KNOCKBACK, 3, true);
        swordMeta.setUnbreakable(true);
        swordMeta.addEnchant(Enchantment.DAMAGE_ALL, 2, true);
        sword.setItemMeta(swordMeta);

        // sets bow metadata
        bowMeta.setDisplayName(ChatColor.RED + "Pew Pew");
        bowMeta.addEnchant(Enchantment.ARROW_KNOCKBACK, 1, true);
        bowMeta.setUnbreakable(true);
        bowMeta.addEnchant(Enchantment.ARROW_INFINITE, 1, true);
        bow.setItemMeta(bowMeta);

        // no need to set arrow metadata! It's just an arrow!

        // sets rocket metadata
        rocketMeta.setPower(2);
        rocket.setItemMeta(rocketMeta);

        // sets elytra metadata
        elytraMeta.setUnbreakable(true);
        elytra.setItemMeta(elytraMeta);

        // sets helmet metadata
        helmetMeta.setColor(Color.RED);
        helmetMeta.setUnbreakable(true);
        helmet.setItemMeta(helmetMeta);

        // sets boots metadata
        bootsMeta.setColor(Color.RED);
        bootsMeta.setUnbreakable(true);
        bootsMeta.addEnchant(Enchantment.PROTECTION_FALL, 3, true);
        boots.setItemMeta(bootsMeta);

        ItemStack[] armor = new ItemStack[4];
        armor[0] = boots;
        armor[1] = null;
        armor[2] = elytra;
        armor[3] = helmet;

        // finally gives players items and sets to max health, ugh!
        ((HumanEntity) player).getInventory().clear();
        ((HumanEntity) player).getInventory().setItem(0, sword);
        ((HumanEntity) player).getInventory().setItem(1, bow);
        ((HumanEntity) player).getInventory().setItem(9, arrow);
        ((HumanEntity) player).getInventory().setItemInOffHand(rocket);
        ((HumanEntity) player).getInventory().setArmorContents(armor);
        player.setHealth(20);
        player.setFoodLevel(20);
    }
}
