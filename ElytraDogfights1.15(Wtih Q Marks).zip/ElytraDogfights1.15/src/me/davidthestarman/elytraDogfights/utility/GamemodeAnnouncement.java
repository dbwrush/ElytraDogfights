package me.davidthestarman.elytraDogfights.utility;

import me.davidthestarman.elytraDogfights.Main;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.DisplaySlot;

public class GamemodeAnnouncement {
    Main main = Main.plugin;

    public void startGameModeAnnouncement() {
        main.scoreboard().getObjective("timer").setDisplaySlot(DisplaySlot.SIDEBAR);
        main.scoreboard().getObjective("timer").setDisplayName(ChatColor.GOLD + "-Game Mode-");
        main.scoreboard().getTeam("�2Game Mode: �e").addEntry("�2Game Mode: �e");
        if (main.TeamsMode == true) {
            main.scoreboard().getTeam("�2Game Mode: �e").setSuffix("Teams");
        } else {
            main.scoreboard().getTeam("�2Game Mode: �e").setSuffix("Free For All");
        }
        main.scoreboard().getObjective("timer").getScore("�2Game Mode: �e").setScore(3);
        for (Player p : main.world.getPlayers()) {

            p.setScoreboard(main.scoreboard());
        }
        new BukkitRunnable() {
            @Override
            public void run() {

                if (main.gameIsRunning == false) {
                    main.scoreboard().clearSlot(DisplaySlot.SIDEBAR);
                    cancel();
                }
            }
        }.runTaskTimer(main, 20, 20);
    }
}
