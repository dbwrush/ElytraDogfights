package me.davidthestarman.elytraDogfights.utility;

import me.davidthestarman.elytraDogfights.Main;
import me.davidthestarman.elytraDogfights.inventory.FFAInventory;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class OnPlayerJoin implements Listener {
    Main main = Main.plugin;
    FFAInventory inv = new FFAInventory();

    @EventHandler
    public void playerJoin(PlayerJoinEvent event) {
    }
}
