package me.davidthestarman.elytraDogfights.utility;

import me.davidthestarman.elytraDogfights.Main;
import me.davidthestarman.elytraDogfights.commands.CommandFFAStartGame;
import me.davidthestarman.elytraDogfights.commands.CommandTeamsStartGame;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class OnPlayerLeave implements Listener {
    CommandFFAStartGame cmdFFA = new CommandFFAStartGame();
    CommandTeamsStartGame cmdTeams = new CommandTeamsStartGame();

    GameplayTimer timer = new GameplayTimer();
    Main main = Main.plugin;

    @EventHandler
    public void playerDeath(PlayerDeathEvent event) {
        Player p = event.getEntity().getPlayer();
        p.setHealth(20);
        p.setFoodLevel(20);
        p.teleport(p.getWorld().getSpawnLocation());
        if(main.inGame.contains(p)) {
            main.inGame.remove(p);
            if(main.scoreboard().getTeam("FFA Team").hasEntry(p.getName())) {
                main.scoreboard().getTeam("FFA Team").removeEntry(p.getName());
                sendMessage(ChatColor.GOLD + p.getName() + ChatColor.GREEN + " has died!");
            } else if(main.scoreboard().getTeam("Blue Team").hasEntry(p.getName())) {
                main.scoreboard().getTeam("Blue Team").removeEntry(p.getName());
                main.blueInGame.remove(p);
                sendMessage(ChatColor.BLUE + p.getName() + ChatColor.GREEN + " has died!");
            } else if(main.scoreboard().getTeam("Red Team").hasEntry(p.getName())) {
                main.scoreboard().getTeam("Red Team").removeEntry(p.getName());
                main.redInGame.remove(p);
                sendMessage(ChatColor.RED + p.getName() + ChatColor.GREEN + " has died!");
            }
            p.getInventory().clear();
            checkInGame();
        }
    }

    @EventHandler
    public void playerLeave(PlayerQuitEvent event) {
        Player p = event.getPlayer();
        if(main.inGame.contains(p)) {
            main.inGame.remove(p);
            if(main.scoreboard().getTeam("FFA Team").hasEntry(p.getName())) {
                main.scoreboard().getTeam("FFA Team").removeEntry(p.getName());
                sendMessage(ChatColor.GOLD + p.getName() + ChatColor.GREEN + " has left the match!");
            } else if(main.scoreboard().getTeam("Blue Team").hasEntry(p.getName())) {
                main.scoreboard().getTeam("Blue Team").removeEntry(p.getName());
                main.blueInGame.remove(p);
                sendMessage(ChatColor.BLUE + p.getName() + ChatColor.GREEN + " has left the match!");
            } else if(main.scoreboard().getTeam("Red Team").hasEntry(p.getName())) {
                main.scoreboard().getTeam("Red Team").removeEntry(p.getName());
                main.redInGame.remove(p);
                sendMessage(ChatColor.RED + p.getName() + ChatColor.GREEN + " has left the match!");
            }
            p.setScoreboard(Bukkit.getServer().getScoreboardManager().getNewScoreboard());
            p.teleport(p.getWorld().getSpawnLocation());
            p.getInventory().clear();
            checkInGame();
        }
    }

    @EventHandler
    public void playerChangeWorld(PlayerChangedWorldEvent event) {
        if(main.world == null) {
            main.world = Bukkit.getWorld(main.worldName);
        }

        Player p = event.getPlayer();
        if(main.inGame.contains(p)) {
            main.inGame.remove(p);
            checkInGame();
        }
        if(p.getWorld().getName().equals(main.world.getName())) {
            new BukkitRunnable() {
                @Override
                public void run() {
                    p.getInventory().clear();
                }
            }.runTaskLater(main, 3);
        }
        p.setScoreboard(main.getServer().getScoreboardManager().getNewScoreboard());
    }

    public void checkInGame() {
        if(!main.TeamsMode) {
            if(main.inGame.size() <= 1) {
                cmdFFA.endGame();
            }
        } else {
            if(main.blueInGame.size() <= 0 || main.redInGame.size() <= 0) {
                cmdTeams.endGame();
            }
        }
    }

    public void sendMessage(String message) {
        for(Player player : main.inGame) {
            player.sendMessage(message);
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1, 1);
        }
    }
}
