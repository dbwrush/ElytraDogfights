package me.davidthestarman.elytraDogfights.commands;

import me.davidthestarman.elytraDogfights.Main;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class CommandToggleGameIsRunning implements CommandExecutor {
    Main main = Main.plugin;

    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if(!sender.isOp()) {
            return false;
        }
        main.gameIsRunning = !main.gameIsRunning;
        sender.sendMessage("gameIsRunning has been set to" + main.gameIsRunning);
        return true;
    }
}
